
import React, { useState } from 'react';
import { useAuth } from '../hooks/useAuth';
import { Link } from 'react-router-dom';
import { COURSES, QUIZZES } from '../constants';
import { Quiz } from '../types';
import { CheckCircleIcon, CodeIcon, LayersIcon } from '../components/icons/Icons';

const ProgressBar: React.FC<{ progress: number }> = ({ progress }) => (
  <div>
    <div className="flex justify-between mb-1">
      <span className="text-base font-medium text-primary dark:text-white">Progress</span>
      <span className="text-sm font-medium text-primary dark:text-white">{progress}%</span>
    </div>
    <div className="w-full bg-gray-200 rounded-full h-2.5 dark:bg-gray-700">
      <div className="bg-primary h-2.5 rounded-full" style={{ width: `${progress}%` }}></div>
    </div>
  </div>
);

const QuizComponent: React.FC<{ quiz: Quiz }> = ({ quiz }) => {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [score, setScore] = useState(0);
  const [showScore, setShowScore] = useState(false);
  const [selectedAnswer, setSelectedAnswer] = useState<string | null>(null);

  const handleAnswer = (option: string) => {
    setSelectedAnswer(option);
    if (option === quiz.questions[currentQuestion].answer) {
      setScore(score + 1);
    }
  };
  
  const nextQuestion = () => {
    setSelectedAnswer(null);
    const nextQ = currentQuestion + 1;
    if (nextQ < quiz.questions.length) {
      setCurrentQuestion(nextQ);
    } else {
      setShowScore(true);
    }
  };

  if (showScore) {
    return (
      <div className="p-6 bg-white dark:bg-gray-800 rounded-lg shadow-md text-center">
        <h3 className="text-2xl font-bold">Quiz Complete!</h3>
        <p className="mt-4 text-lg">Your score: {score} / {quiz.questions.length}</p>
        <p className="mt-2 text-primary font-semibold">Completion Certificate (Placeholder)</p>
        <button onClick={() => {setShowScore(false); setCurrentQuestion(0); setScore(0);}} className="mt-6 px-6 py-2 bg-primary text-white rounded-lg hover:bg-primary-dark">
          Retake Quiz
        </button>
      </div>
    );
  }

  return (
    <div className="p-6 bg-white dark:bg-gray-800 rounded-lg shadow-md">
      <h3 className="text-xl font-bold mb-4">{quiz.title}</h3>
      <div className="mb-4">
        <p className="font-semibold">{currentQuestion + 1}. {quiz.questions[currentQuestion].question}</p>
      </div>
      <div className="space-y-3">
        {quiz.questions[currentQuestion].options.map(option => (
          <button
            key={option}
            onClick={() => handleAnswer(option)}
            disabled={!!selectedAnswer}
            className={`block w-full text-left p-3 rounded-lg border-2 transition-colors ${
              selectedAnswer
                ? option === quiz.questions[currentQuestion].answer
                  ? 'bg-green-100 dark:bg-green-900 border-green-500'
                  : option === selectedAnswer
                  ? 'bg-red-100 dark:bg-red-900 border-red-500'
                  : 'bg-gray-100 dark:bg-gray-700 border-gray-300 dark:border-gray-600'
                : 'bg-gray-100 dark:bg-gray-700 border-gray-300 dark:border-gray-600 hover:border-primary'
            }`}
          >
            {option}
          </button>
        ))}
      </div>
      {selectedAnswer && (
        <button onClick={nextQuestion} className="mt-6 px-6 py-2 bg-secondary text-white rounded-lg hover:bg-secondary-dark">
          Next
        </button>
      )}
    </div>
  );
};

const MyLearnings: React.FC = () => {
  const { user } = useAuth();
  const [activeCourseId, setActiveCourseId] = useState(COURSES[0].id);
  const activeCourse = COURSES.find(c => c.id === activeCourseId);
  const activeQuiz = activeCourseId ? QUIZZES[activeCourseId] : undefined;

  if (!user || user.role !== 'student') {
    return (
      <div className="container mx-auto px-4 py-16 text-center">
        <h1 className="text-3xl font-bold">Access Denied</h1>
        <p className="mt-2 text-lg text-gray-600 dark:text-gray-400">Please log in as a student to view your learnings.</p>
        <Link to="/login" className="mt-6 inline-block px-6 py-3 font-semibold text-white bg-primary rounded-lg shadow-md hover:bg-primary-dark">
          Login
        </Link>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-100 dark:bg-gray-950">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <h1 className="text-4xl font-bold mb-2">Welcome, {user.name}!</h1>
        <p className="text-lg text-gray-600 dark:text-gray-400 mb-8">Continue your learning journey.</p>
        
        <div className="lg:grid lg:grid-cols-4 lg:gap-8">
          {/* Sidebar with courses */}
          <aside className="lg:col-span-1 mb-8 lg:mb-0">
            <div className="p-4 bg-white dark:bg-gray-800 rounded-lg shadow-md">
              <h2 className="text-xl font-bold mb-4">Your Courses</h2>
              <ul className="space-y-2">
                {COURSES.slice(0,3).map(course => ( // Assuming student is enrolled in first 3 courses
                  <li key={course.id}>
                    <button
                      onClick={() => setActiveCourseId(course.id)}
                      className={`w-full text-left p-3 rounded-lg font-medium transition-colors ${
                        activeCourseId === course.id
                          ? 'bg-primary-light/20 text-primary'
                          : 'hover:bg-gray-100 dark:hover:bg-gray-700'
                      }`}
                    >
                      {course.title}
                    </button>
                  </li>
                ))}
              </ul>
            </div>
          </aside>
          
          {/* Main Content */}
          <main className="lg:col-span-3">
            {activeCourse && (
              <div className="space-y-8">
                <div className="p-6 bg-white dark:bg-gray-800 rounded-lg shadow-md">
                  <h2 className="text-2xl font-bold mb-4">{activeCourse.title}</h2>
                  <ProgressBar progress={65} />
                </div>

                <div className="p-6 bg-white dark:bg-gray-800 rounded-lg shadow-md">
                  <h3 className="text-xl font-bold mb-4">Current Lesson: {activeCourse.plan.week3[2]}</h3>
                  <div className="aspect-video bg-black rounded-lg flex items-center justify-center text-white">
                    <LayersIcon className="h-16 w-16 text-gray-500" />
                    <p className="absolute">Animated Video Lesson (Placeholder)</p>
                  </div>
                  <div className="mt-4 flex space-x-4">
                    <button className="px-6 py-2 bg-primary text-white rounded-lg hover:bg-primary-dark">Resume Lesson</button>
                    <button className="px-6 py-2 flex items-center bg-gray-200 dark:bg-gray-700 rounded-lg hover:bg-gray-300 dark:hover:bg-gray-600">
                      <CodeIcon className="h-5 w-5 mr-2" /> Download Notes
                    </button>
                  </div>
                </div>

                {activeQuiz && <QuizComponent quiz={activeQuiz} />}

              </div>
            )}
          </main>
        </div>
      </div>
    </div>
  );
};

export default MyLearnings;
