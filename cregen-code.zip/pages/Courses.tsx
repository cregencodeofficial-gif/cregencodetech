
import React from 'react';
import { Link } from 'react-router-dom';
import { COURSES } from '../constants';
import { Course } from '../types';
import { ChevronRightIcon } from '../components/icons/Icons';

const CourseListItem: React.FC<{ course: Course }> = ({ course }) => (
  <Link 
    to={`/courses/${course.id}`} 
    className="block p-6 bg-white dark:bg-gray-800 rounded-lg shadow-md hover:shadow-xl hover:scale-105 transform transition-all duration-300 border border-gray-200 dark:border-gray-700"
  >
    <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between">
      <div className="flex items-center mb-4 sm:mb-0">
        <div className="p-3 bg-primary-light/20 rounded-full mr-4">
          <course.icon className="h-8 w-8 text-primary" />
        </div>
        <div>
          <h3 className="text-xl font-bold text-gray-900 dark:text-white">{course.title}</h3>
          <p className="text-sm text-gray-500 dark:text-gray-400">Duration: {course.duration}</p>
        </div>
      </div>
      <div className="flex items-center text-primary font-semibold">
        View Details
        <ChevronRightIcon className="ml-2 h-5 w-5" />
      </div>
    </div>
    <p className="mt-4 text-gray-600 dark:text-gray-300">{course.description}</p>
  </Link>
);


const Courses: React.FC = () => {
  return (
    <div className="animate-fade-in">
      {/* Header Section */}
      <section className="py-20 bg-gradient-to-b from-primary-light/10 to-transparent dark:from-primary/10">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl md:text-5xl font-extrabold text-gray-900 dark:text-white">Our Courses</h1>
          <p className="mt-4 max-w-3xl mx-auto text-lg text-gray-600 dark:text-gray-300">
            Explore our range of 30-day, career-focused programs designed to make you job-ready.
          </p>
        </div>
      </section>

      {/* Courses List */}
      <section className="py-16 sm:py-24">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="space-y-8">
            {COURSES.map((course) => (
              <CourseListItem key={course.id} course={course} />
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default Courses;
