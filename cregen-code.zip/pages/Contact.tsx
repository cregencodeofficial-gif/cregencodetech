
import React from 'react';
import { MailIcon, PhoneIcon, TwitterIcon, GithubIcon, LinkedinIcon } from '../components/icons/Icons';

const Contact: React.FC = () => {
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    alert('Thank you for your message! We will get back to you soon.');
    // In a real app, this would submit to an API endpoint.
  };

  return (
    <div className="animate-fade-in">
      <section className="py-20 bg-gradient-to-b from-primary-light/10 to-transparent dark:from-primary/10">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl md:text-5xl font-extrabold text-gray-900 dark:text-white">Get In Touch</h1>
          <p className="mt-4 max-w-3xl mx-auto text-lg text-gray-600 dark:text-gray-300">
            Have questions about our courses, partnerships, or anything else? We're here to help.
          </p>
        </div>
      </section>

      <section className="py-16 sm:py-24">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            {/* Contact Form */}
            <div className="bg-white dark:bg-gray-800 p-8 rounded-lg shadow-lg border border-gray-200 dark:border-gray-700">
              <h2 className="text-3xl font-bold mb-6">Send us a Message</h2>
              <form onSubmit={handleSubmit} className="space-y-6">
                <div>
                  <label htmlFor="name" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Full Name</label>
                  <input type="text" id="name" required className="mt-1 block w-full px-3 py-2 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary" />
                </div>
                <div>
                  <label htmlFor="email" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Email Address</label>
                  <input type="email" id="email" required className="mt-1 block w-full px-3 py-2 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary" />
                </div>
                <div>
                  <label htmlFor="message" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Message</label>
                  <textarea id="message" rows={5} required className="mt-1 block w-full px-3 py-2 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary"></textarea>
                </div>
                <div>
                  <button type="submit" className="w-full px-6 py-3 text-lg font-semibold text-white bg-primary rounded-lg shadow-md hover:bg-primary-dark transition-colors">
                    Submit
                  </button>
                </div>
              </form>
            </div>

            {/* Contact Info */}
            <div className="space-y-8">
              <div>
                <h3 className="text-2xl font-bold mb-4">Contact Information</h3>
                <div className="space-y-4 text-lg text-gray-700 dark:text-gray-300">
                  <p className="flex items-center"><MailIcon className="h-6 w-6 mr-3 text-primary" /> cregencode.official@gmail.com</p>
                  <p className="flex items-center"><PhoneIcon className="h-6 w-6 mr-3 text-primary" /> 8012125422 / 9345154711</p>
                </div>
              </div>
              <div>
                <h3 className="text-2xl font-bold mb-4">Course Registration</h3>
                 <p className="mb-4 text-lg text-gray-700 dark:text-gray-300">Register for any of our courses through our Google Form.</p>
                 <a href="https://docs.google.com/forms/d/e/1FAIpQLSeW-wB-deFpLe-4J7s8VZV_2z8B-j5fJ3E5FzF-yH9wI_O_rQ/viewform?usp=sf_link" target="_blank" rel="noopener noreferrer" className="inline-block px-6 py-3 font-semibold text-white bg-secondary rounded-lg shadow-md hover:bg-secondary-dark transition-colors">
                    Register Now
                 </a>
              </div>
              <div>
                <h3 className="text-2xl font-bold mb-4">Follow Us</h3>
                <div className="flex space-x-6">
                  <a href="#" className="text-gray-500 hover:text-primary transition-colors"><TwitterIcon className="h-8 w-8" /></a>
                  <a href="#" className="text-gray-500 hover:text-primary transition-colors"><GithubIcon className="h-8 w-8" /></a>
                  <a href="#" className="text-gray-500 hover:text-primary transition-colors"><LinkedinIcon className="h-8 w-8" /></a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Contact;
