
import React from 'react';
import { Link } from 'react-router-dom';
import { COURSES } from '../constants';
import { ChevronRightIcon, BrainCircuitIcon, LayersIcon, CheckCircleIcon } from '../components/icons/Icons';
import { Course } from '../types';

const CourseCard: React.FC<{ course: Course }> = ({ course }) => (
  <div className="bg-white dark:bg-gray-800 rounded-lg shadow-lg overflow-hidden transform hover:-translate-y-2 transition-transform duration-300">
    <div className="p-6">
      <div className="flex items-center space-x-4 mb-4">
        <div className="p-3 bg-primary-light/20 rounded-full">
          <course.icon className="h-6 w-6 text-primary" />
        </div>
        <h3 className="text-xl font-bold text-gray-900 dark:text-white">{course.title}</h3>
      </div>
      <p className="text-gray-600 dark:text-gray-400 h-20">{course.description}</p>
      <Link to={`/courses/${course.id}`} className="mt-4 inline-flex items-center font-semibold text-primary hover:text-primary-dark">
        Learn More <ChevronRightIcon className="ml-1 h-5 w-5" />
      </Link>
    </div>
  </div>
);

const WhyChooseUsCard: React.FC<{ icon: React.ReactNode; title: string; description: string }> = ({ icon, title, description }) => (
  <div className="bg-white dark:bg-gray-800/50 p-6 rounded-lg shadow-md border border-gray-200 dark:border-gray-700">
    <div className="flex items-center justify-center h-12 w-12 rounded-full bg-primary-light/20 text-primary mb-4">
      {icon}
    </div>
    <h3 className="text-lg font-semibold mb-2">{title}</h3>
    <p className="text-gray-600 dark:text-gray-400">{description}</p>
  </div>
);

const Home: React.FC = () => {
  return (
    <div className="animate-fade-in">
      {/* Hero Section */}
      <section className="relative py-20 md:py-32 bg-gradient-to-br from-gray-50 to-gray-100 dark:from-gray-900 dark:to-black overflow-hidden">
        <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAzMiAzMiIgd2lkdGg9IjMyIiBoZWlnaHQ9IjMyIiBmaWxsPSJub25lIiBzdHJva2U9InJnYmEoMTUsIDEyOCwgMTE3LCAwLjA4KSI+PHBhdGggZD0iTTAtMSAwIDEgTS0xIDAgMSAwIi8+PC9zdmc+')] opacity-75"></div>
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10">
          <h1 className="text-4xl md:text-6xl font-extrabold text-gray-900 dark:text-white tracking-tight">
            <span className="block">Cregen Code – Empowering</span>
            <span className="block text-primary">Future Tech Leaders</span>
          </h1>
          <p className="mt-6 max-w-2xl mx-auto text-lg md:text-xl text-gray-600 dark:text-gray-300">
            Master In-Demand Skills with Structured Learning & Real-World Projects
          </p>
          <div className="mt-10 flex items-center justify-center">
            <Link to="/courses" className="w-full sm:w-auto px-8 py-3 text-lg font-semibold text-white bg-primary rounded-lg shadow-lg hover:bg-primary-dark transform hover:scale-105 transition-all duration-300">
              Explore Courses
            </Link>
          </div>
        </div>
      </section>

      {/* Course Highlights Section */}
      <section className="py-16 sm:py-24 bg-gray-50 dark:bg-gray-900">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold tracking-tight">Our Popular Courses</h2>
            <p className="mt-4 max-w-2xl mx-auto text-lg text-gray-600 dark:text-gray-400">
              Kickstart your tech career with our expertly designed 30-day programs.
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {COURSES.slice(0, 4).map((course) => (
              <CourseCard key={course.id} course={course} />
            ))}
          </div>
          <div className="text-center mt-12">
            <Link to="/courses" className="px-6 py-3 font-semibold text-white bg-secondary rounded-lg shadow-md hover:bg-secondary-dark transition-colors">
              View All Courses
            </Link>
          </div>
        </div>
      </section>

      {/* Why Choose Us Section */}
      <section className="py-16 sm:py-24 bg-white dark:bg-gray-950">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold tracking-tight">Why Cregen Code?</h2>
            <p className="mt-4 max-w-2xl mx-auto text-lg text-gray-600 dark:text-gray-400">
              We provide a learning experience that's structured, practical, and career-focused.
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <WhyChooseUsCard 
              icon={<BrainCircuitIcon className="h-6 w-6"/>}
              title="Structured Learning Path" 
              description="Our 30-day programs are designed to take you from beginner to job-ready with a clear, step-by-step curriculum."
            />
            <WhyChooseUsCard
              icon={<LayersIcon className="h-6 w-6"/>}
              title="Real-World Projects"
              description="Build a portfolio that stands out. Every course culminates in a hands-on project that mirrors industry challenges."
            />
            <WhyChooseUsCard
              icon={<CheckCircleIcon className="h-6 w-6"/>}
              title="Expert Mentorship"
              description="Get guidance and support from industry professionals who are dedicated to your success and career growth."
            />
          </div>
        </div>
      </section>

      {/* Call-to-action Banner */}
      <section className="bg-primary">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-16 text-center">
          <h2 className="text-3xl font-bold text-white">Ready to Start Your Tech Journey?</h2>
          <p className="mt-4 text-lg text-primary-light">Join Cregen Code today and build the skills for a successful career.</p>
          <div className="mt-8">
            <Link to="/courses" className="px-8 py-3 text-lg font-semibold text-primary bg-white rounded-lg shadow-lg hover:bg-gray-100 transform hover:scale-105 transition-all duration-300">
              Enroll Now
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;
