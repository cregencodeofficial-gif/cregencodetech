
import React from 'react';
import { useParams, Link } from 'react-router-dom';
import { COURSES, QUIZZES } from '../constants';
import { CheckCircleIcon, CodeIcon, LayersIcon } from '../components/icons/Icons';

const programOverviewItems = [
    "Programming + Hands on experience",
    "Tools Features",
    "Career growth",
    "Flexibility timings ( 6 days 8:00 pm to 9:00 pm)",
    "Certification",
    "Doubt clearing",
    "Fee applicable ( per 50)",
    "Career platforms enhancement session"
];

const programStructureItems = [
    "Syllabus",
    "Practical learning + problem solving",
    "How to use IDE",
    "Soft skills (communication)",
    "Resume Building and Career path",
    "Quiz",
    "Leet code + hacker rank",
    "Real world example + problem solving"
];

const InfoList: React.FC<{title: string, items: string[]}> = ({title, items}) => (
    <div>
        <h3 className="text-2xl font-bold mb-4">{title}</h3>
        <ul className="space-y-3">
            {items.map((item, index) => (
                <li key={index} className="flex items-start">
                    <CheckCircleIcon className="h-6 w-6 text-primary mr-3 mt-1 flex-shrink-0" />
                    <span className="text-gray-700 dark:text-gray-300">{item}</span>
                </li>
            ))}
        </ul>
    </div>
);


const CourseDetail: React.FC = () => {
  const { courseId } = useParams<{ courseId: string }>();
  const course = COURSES.find(c => c.id === courseId);
  const quiz = courseId ? QUIZZES[courseId] : undefined;

  if (!course) {
    return (
      <div className="container mx-auto px-4 py-16 text-center">
        <h1 className="text-3xl font-bold">Course not found</h1>
        <Link to="/courses" className="mt-4 inline-block text-primary hover:underline">
          Back to all courses
        </Link>
      </div>
    );
  }

  const renderPlan = (title: string, items: string[]) => (
    <div className="mb-6">
      <h4 className="text-xl font-semibold mb-3 text-gray-800 dark:text-gray-200">{title}</h4>
      <ul className="space-y-2">
        {items.map((item, index) => (
          <li key={index} className="flex items-start">
            <CheckCircleIcon className="h-5 w-5 text-green-500 mr-3 mt-1 flex-shrink-0" />
            <span className="text-gray-600 dark:text-gray-400">{item}</span>
          </li>
        ))}
      </ul>
    </div>
  );
  
  return (
    <div className="animate-fade-in">
      {/* Course Header */}
      <section className="py-20 bg-gradient-to-b from-primary-light/10 to-transparent dark:from-primary/10">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center space-x-4">
            <div className="p-4 bg-white dark:bg-gray-800 rounded-lg shadow-md">
              <course.icon className="h-10 w-10 text-primary" />
            </div>
            <div>
              <h1 className="text-4xl md:text-5xl font-extrabold text-gray-900 dark:text-white">{course.title}</h1>
              <p className="mt-2 text-lg text-gray-600 dark:text-gray-300">{course.description}</p>
            </div>
          </div>
        </div>
      </section>

      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="lg:grid lg:grid-cols-3 lg:gap-12">
          {/* Main Content */}
          <div className="lg:col-span-2">
            {/* Overview */}
            <div className="mb-12">
              <h2 className="text-3xl font-bold mb-4">Course Overview</h2>
              <p className="text-gray-700 dark:text-gray-300 leading-relaxed">
                This {course.duration} program is an immersive journey into {course.title}. You'll start with the fundamentals and progressively build your skills through hands-on exercises and practical application, culminating in a real-world project to showcase your abilities.
              </p>
            </div>
            
            {/* Program Details */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-12 mb-12">
                <InfoList title="Program Overview" items={programOverviewItems} />
                <InfoList title="Program Structure" items={programStructureItems} />
            </div>

            {/* 30-Day Plan */}
            <div>
              <h2 className="text-3xl font-bold mb-6">Structured 30-Day Completion Plan</h2>
              <div className="space-y-8">
                {renderPlan("Week 1: Fundamentals", course.plan.week1)}
                {renderPlan("Week 2: Core Concepts", course.plan.week2)}
                {renderPlan("Week 3: Practical Implementation", course.plan.week3)}
                {renderPlan("Week 4: Real-World Project + Final Assessment", course.plan.week4)}
              </div>
            </div>
          </div>

          {/* Sidebar */}
          <aside className="mt-12 lg:mt-0">
            <div className="sticky top-24 p-6 bg-white dark:bg-gray-800 rounded-lg shadow-lg border border-gray-200 dark:border-gray-700">
              <h3 className="text-2xl font-bold mb-4">Course Details</h3>
              
              <div className="mb-4">
                <h4 className="font-semibold text-gray-800 dark:text-gray-200">Skills You'll Gain:</h4>
                <div className="flex flex-wrap gap-2 mt-2">
                  {course.skills.map(skill => (
                    <span key={skill} className="px-3 py-1 text-sm bg-primary-light/20 text-primary-dark dark:text-primary-light rounded-full">{skill}</span>
                  ))}
                </div>
              </div>
              
              <div className="mb-6">
                <h4 className="font-semibold text-gray-800 dark:text-gray-200">Tools You'll Use:</h4>
                <div className="flex flex-wrap gap-2 mt-2">
                  {course.tools.map(tool => (
                    <span key={tool} className="px-3 py-1 text-sm bg-gray-200 dark:bg-gray-700 text-gray-800 dark:text-gray-200 rounded-full">{tool}</span>
                  ))}
                </div>
              </div>

              {/* Learning Resources */}
              <div className="space-y-3 mb-6">
                <p className="flex items-center"><LayersIcon className="h-5 w-5 mr-2 text-primary"/> Animated video lessons</p>
                <p className="flex items-center"><CodeIcon className="h-5 w-5 mr-2 text-primary"/> Downloadable notes (PDF)</p>
                {quiz && <p className="flex items-center"><CheckCircleIcon className="h-5 w-5 mr-2 text-primary"/> Interactive quizzes</p>}
              </div>
              
              <a href="https://docs.google.com/forms/d/e/1FAIpQLSeW-wB-deFpLe-4J7s8VZV_2z8B-j5fJ3E5FzF-yH9wI_O_rQ/viewform?usp=sf_link" target="_blank" rel="noopener noreferrer" className="block w-full text-center px-6 py-3 text-lg font-semibold text-white bg-secondary rounded-lg shadow-md hover:bg-secondary-dark transition-colors">
                Enroll Now
              </a>
            </div>
          </aside>
        </div>
      </div>
    </div>
  );
};

export default CourseDetail;
