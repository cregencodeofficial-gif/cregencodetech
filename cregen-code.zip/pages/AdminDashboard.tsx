
import React, { useState } from 'react';
import { useAuth } from '../hooks/useAuth';
import { Link } from 'react-router-dom';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

const data = [
  { name: 'Jan', registrations: 40, signups: 24 },
  { name: 'Feb', registrations: 30, signups: 13 },
  { name: 'Mar', registrations: 20, signups: 98 },
  { name: 'Apr', registrations: 27, signups: 39 },
  { name: 'May', registrations: 18, signups: 48 },
  { name: 'Jun', registrations: 23, signups: 38 },
];

const AdminDashboard: React.FC = () => {
  const { user } = useAuth();
  const [siteTitle, setSiteTitle] = useState('Cregen Code – Empowering Future Tech Leaders');
  const [heroTagline, setHeroTagline] = useState('Master In-Demand Skills with Structured Learning & Real-World Projects');

  if (!user || user.role !== 'admin') {
    return (
      <div className="container mx-auto px-4 py-16 text-center">
        <h1 className="text-3xl font-bold">Access Denied</h1>
        <p className="mt-2 text-lg text-gray-600 dark:text-gray-400">You must be an administrator to view this page.</p>
        <Link to="/login" className="mt-6 inline-block px-6 py-3 font-semibold text-white bg-primary rounded-lg shadow-md hover:bg-primary-dark">
          Login
        </Link>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-100 dark:bg-gray-950">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <h1 className="text-4xl font-bold mb-8">Admin Dashboard</h1>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-md">
                <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400">Total Students</h3>
                <p className="mt-1 text-3xl font-semibold text-gray-900 dark:text-white">1,234</p>
            </div>
            <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-md">
                <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400">Courses</h3>
                <p className="mt-1 text-3xl font-semibold text-gray-900 dark:text-white">8</p>
            </div>
            <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-md">
                <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400">Feedback Submissions</h3>
                <p className="mt-1 text-3xl font-semibold text-gray-900 dark:text-white">56</p>
            </div>
            <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-md">
                <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400">Revenue (Month)</h3>
                <p className="mt-1 text-3xl font-semibold text-gray-900 dark:text-white">$12,450</p>
            </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main content area */}
          <div className="lg:col-span-2 space-y-8">
            {/* Analytics */}
            <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-md">
              <h2 className="text-xl font-bold mb-4">Analytics</h2>
              <div className="w-full h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={data}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" />
                    <YAxis />
                    <Tooltip contentStyle={{ backgroundColor: 'rgba(31, 41, 55, 0.8)', border: 'none' }}/>
                    <Legend />
                    <Bar dataKey="registrations" fill="#0D9488" />
                    <Bar dataKey="signups" fill="#F97316" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Content Editor */}
            <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-md">
              <h2 className="text-xl font-bold mb-4">Edit Home Page Content (Live Demo)</h2>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium">Hero Headline</label>
                  <input type="text" value={siteTitle} onChange={(e) => setSiteTitle(e.target.value)} className="mt-1 block w-full px-3 py-2 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-md" />
                </div>
                <div>
                  <label className="block text-sm font-medium">Hero Tagline</label>
                  <textarea rows={3} value={heroTagline} onChange={(e) => setHeroTagline(e.target.value)} className="mt-1 block w-full px-3 py-2 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-md"></textarea>
                </div>
                <button className="px-4 py-2 bg-primary text-white rounded-md hover:bg-primary-dark">Save Changes</button>
              </div>
              <div className="mt-6 p-4 border-dashed border-2 border-gray-300 dark:border-gray-600 rounded-md">
                  <h3 className="font-semibold text-center mb-2">Live Preview</h3>
                  <div className="text-center">
                    <h1 className="text-2xl font-bold">{siteTitle}</h1>
                    <p className="text-md text-gray-600 dark:text-gray-400">{heroTagline}</p>
                  </div>
              </div>
            </div>
          </div>
          
          {/* Sidebar for quick actions */}
          <div className="space-y-8">
            <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-md">
              <h2 className="text-xl font-bold mb-4">Quick Actions</h2>
              <div className="space-y-3">
                <button className="w-full text-left p-3 rounded-lg font-medium bg-primary-light/20 text-primary hover:bg-primary-light/30">Manage Courses</button>
                <button className="w-full text-left p-3 rounded-lg font-medium bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600">Create Blog Post</button>
                <button className="w-full text-left p-3 rounded-lg font-medium bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600">View Student Registrations</button>
                <button className="w-full text-left p-3 rounded-lg font-medium bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600">View Feedback</button>
              </div>
            </div>
            <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-md">
              <h2 className="text-xl font-bold mb-4">Site Customization</h2>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium">Theme</label>
                  <select className="mt-1 block w-full px-3 py-2 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-md">
                    <option>Light/Dark Mode</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium">Primary Color</label>
                  <input type="color" defaultValue="#0D9488" className="mt-1 block w-full" />
                </div>
                <button className="w-full px-4 py-2 bg-secondary text-white rounded-md hover:bg-secondary-dark">Apply Customizations</button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;
