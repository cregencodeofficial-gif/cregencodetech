// FIX: Import React to resolve 'Cannot find namespace 'React'' error.
import React from 'react';

export interface Course {
  id: string;
  title: string;
  description: string;
  icon: React.ComponentType<{ className?: string }>;
  skills: string[];
  tools: string[];
  duration: string;
  plan: {
    week1: string[];
    week2: string[];
    week3: string[];
    week4: string[];
  };
}

export type UserRole = 'guest' | 'student' | 'admin';

export interface User {
  name: string;
  role: UserRole;
}

export interface Quiz {
  id: string;
  title: string;
  questions: {
    question: string;
    options: string[];
    answer: string;
  }[];
}