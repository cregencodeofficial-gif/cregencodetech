
import React from 'react';
import { Link } from 'react-router-dom';
import { Logo } from './Logo';
import { TwitterIcon, GithubIcon, LinkedinIcon, MailIcon, PhoneIcon } from './icons/Icons';

const Footer: React.FC = () => {
  return (
    <footer className="bg-gray-100 dark:bg-gray-950 border-t border-gray-200 dark:border-gray-800">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Brand and Info */}
          <div className="space-y-4">
            <Link to="/" className="flex items-center space-x-2">
              <Logo className="h-10 w-auto" />
              <span className="text-2xl font-bold text-gray-800 dark:text-white">Cregen Code</span>
            </Link>
            <p className="text-sm text-gray-600 dark:text-gray-400">
              Empowering the next generation of tech leaders with practical, project-based learning.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-gray-500 hover:text-primary transition-colors"><TwitterIcon className="h-6 w-6" /></a>
              <a href="#" className="text-gray-500 hover:text-primary transition-colors"><GithubIcon className="h-6 w-6" /></a>
              <a href="#" className="text-gray-500 hover:text-primary transition-colors"><LinkedinIcon className="h-6 w-6" /></a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-sm font-semibold text-gray-900 dark:text-white tracking-wider uppercase">Quick Links</h3>
            <ul className="mt-4 space-y-2">
              <li><Link to="/about" className="text-sm text-gray-600 dark:text-gray-400 hover:text-primary">About Us</Link></li>
              <li><Link to="/courses" className="text-sm text-gray-600 dark:text-gray-400 hover:text-primary">Courses</Link></li>
              <li><Link to="/contact" className="text-sm text-gray-600 dark:text-gray-400 hover:text-primary">Contact</Link></li>
              <li><Link to="/login" className="text-sm text-gray-600 dark:text-gray-400 hover:text-primary">Admin Login</Link></li>
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h3 className="text-sm font-semibold text-gray-900 dark:text-white tracking-wider uppercase">Contact Us</h3>
            <ul className="mt-4 space-y-3">
              <li className="flex items-center space-x-3 text-sm text-gray-600 dark:text-gray-400">
                <MailIcon className="h-5 w-5 text-primary" />
                <a href="mailto:cregencode.official@gmail.com" className="hover:text-primary">cregencode.official@gmail.com</a>
              </li>
              <li className="flex items-center space-x-3 text-sm text-gray-600 dark:text-gray-400">
                <PhoneIcon className="h-5 w-5 text-primary" />
                <span>8012125422 / 9345154711</span>
              </li>
            </ul>
          </div>

          {/* Newsletter */}
          <div>
            <h3 className="text-sm font-semibold text-gray-900 dark:text-white tracking-wider uppercase">Stay Updated</h3>
            <p className="mt-4 text-sm text-gray-600 dark:text-gray-400">Subscribe to our newsletter for the latest course updates and tech news.</p>
            <form className="mt-4 flex">
              <input type="email" placeholder="Enter your email" className="flex-grow min-w-0 px-4 py-2 text-sm border border-gray-300 rounded-l-md focus:ring-primary focus:border-primary dark:bg-gray-800 dark:border-gray-700" />
              <button type="submit" className="px-4 py-2 text-sm font-medium text-white bg-primary rounded-r-md hover:bg-primary-dark transition-colors">Subscribe</button>
            </form>
          </div>
        </div>
        
        <div className="mt-12 pt-8 border-t border-gray-200 dark:border-gray-800 text-center text-sm text-gray-500 dark:text-gray-400">
          <p>&copy; {new Date().getFullYear()} Cregen Code. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
