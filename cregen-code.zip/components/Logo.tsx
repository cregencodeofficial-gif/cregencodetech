
import React from 'react';

export const Logo: React.FC<{ className?: string }> = ({ className }) => (
  <svg
    className={className}
    viewBox="0 0 200 60"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    aria-label="Cregen Code Logo"
  >
    {/* First C */}
    <g className="text-primary">
      <path
        d="M50 5 L20 5 L5 25 L5 35 L20 55 L50 55"
        stroke="currentColor"
        strokeWidth="5"
        strokeLinejoin="round"
        strokeLinecap="round"
      />
      <path
        d="M40 15 L20 15 L15 25 L15 35 L20 45 L40 45"
        stroke="currentColor"
        strokeWidth="5"
        strokeLinejoin="round"
        strokeLinecap="round"
      />
    </g>
    {/* Second C */}
    <g className="text-primary" transform="translate(60, 0)">
      <path
        d="M50 5 L20 5 L5 25 L5 35 L20 55 L50 55"
        stroke="currentColor"
        strokeWidth="5"
        strokeLinejoin="round"
        strokeLinecap="round"
      />
      <path
        d="M40 15 L20 15 L15 25 L15 35 L20 45 L40 45"
        stroke="currentColor"
        strokeWidth="5"
        strokeLinejoin="round"
        strokeLinecap="round"
      />
    </g>
    {/* T */}
    <g className="text-secondary" transform="translate(125, 0)">
       <path d="M5 5 L65 5" stroke="currentColor" strokeWidth="5" strokeLinecap="round" />
       <path d="M5 15 L65 15" stroke="currentColor" strokeWidth="5" strokeLinecap="round" />
       <path d="M30 15 L30 55" stroke="currentColor" strokeWidth="5" strokeLinecap="round" />
       <path d="M40 15 L40 55" stroke="currentColor" strokeWidth="5" strokeLinecap="round" />
    </g>
  </svg>
);
