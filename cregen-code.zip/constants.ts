
import { Course, Quiz } from './types';
import { CodeIcon, DatabaseIcon, BrainCircuitIcon, BrushIcon, LayersIcon, BarChartIcon, CpuIcon, TerminalIcon } from './components/icons/Icons';

export const COURSES: Course[] = [
  {
    id: 'java',
    title: 'Java',
    description: 'Master Java programming from fundamentals to advanced topics, preparing for enterprise-level application development.',
    icon: CodeIcon,
    skills: ['Core Java', 'OOP', 'Data Structures', 'Multithreading', 'Spring Boot'],
    tools: ['IntelliJ IDEA', 'Maven', 'Git', 'JUnit', 'Spring'],
    duration: '30 Days',
    plan: {
      week1: ['Java Basics', 'Variables & Data Types', 'Control Flow', 'Object-Oriented Programming (OOP) Introduction'],
      week2: ['Inheritance & Polymorphism', 'Abstract Classes & Interfaces', 'Exception Handling', 'Collections Framework'],
      week3: ['Generics', 'Multithreading', 'File I/O', 'Introduction to Spring Boot'],
      week4: ['Building a REST API with Spring Boot', 'Database Connectivity (JDBC/JPA)', 'Final Project: Web Application', 'Final Assessment'],
    },
  },
  {
    id: 'python',
    title: 'Python',
    description: 'Become proficient in Python, one of the most versatile languages for web development, data science, and AI.',
    icon: CodeIcon,
    skills: ['Python Syntax', 'Data Structures', 'OOP', 'Flask/Django', 'API Development'],
    tools: ['VS Code', 'Pip', 'Git', 'Pytest', 'Flask'],
    duration: '30 Days',
    plan: {
      week1: ['Python Fundamentals', 'Data Types and Structures', 'Functions and Modules', 'Control Structures'],
      week2: ['Object-Oriented Python', 'File Handling', 'Standard Library', 'Virtual Environments & Pip'],
      week3: ['Introduction to Web Frameworks (Flask)', 'Routing and Templates', 'Building a Simple API', 'Database Integration with SQLAlchemy'],
      week4: ['Real-World Project: Blog Platform', 'Testing with Pytest', 'Deployment Concepts', 'Final Assessment'],
    },
  },
  {
    id: 'ui-ux',
    title: 'UI/UX Design',
    description: 'Learn the principles of user-centric design, from wireframing and prototyping to creating beautiful and intuitive interfaces.',
    icon: BrushIcon,
    skills: ['User Research', 'Wireframing', 'Prototyping', 'Visual Design', 'Usability Testing'],
    tools: ['Figma', 'Adobe XD', 'Sketch', 'InVision', 'Miro'],
    duration: '30 Days',
    plan: {
      week1: ['Intro to UI/UX', 'Design Thinking Process', 'User Research Methods', 'Creating User Personas'],
      week2: ['Information Architecture', 'Wireframing & Prototyping', 'Usability Principles', 'Figma Fundamentals'],
      week3: ['Visual Design Principles (Color, Typography)', 'UI Kits & Design Systems', 'Responsive Design', 'Interactive Prototyping'],
      week4: ['Usability Testing', 'Portfolio Project: Mobile App Design', 'Handoff to Developers', 'Final Assessment'],
    },
  },
  {
    id: 'frontend',
    title: 'Front-end Development',
    description: 'Build modern, responsive, and interactive user interfaces for the web using React, TypeScript, and Tailwind CSS.',
    icon: LayersIcon,
    skills: ['HTML5', 'CSS3', 'JavaScript (ES6+)', 'React', 'TypeScript', 'Tailwind CSS', 'API Integration'],
    tools: ['VS Code', 'Node.js', 'Git', 'React DevTools', 'Vite'],
    duration: '30 Days',
    plan: {
      week1: ['HTML & CSS Fundamentals', 'Responsive Design & Flexbox/Grid', 'JavaScript Basics', 'DOM Manipulation'],
      week2: ['Advanced JavaScript (ES6+)', 'Introduction to React', 'Components, Props, and State', 'React Hooks'],
      week3: ['Styling with Tailwind CSS', 'Client-Side Routing (React Router)', 'API Calls with Fetch/Axios', 'State Management (Context API)'],
      week4: ['Real-World Project: E-commerce Frontend', 'TypeScript with React', 'Performance Optimization', 'Final Assessment'],
    },
  },
  {
    id: 'backend',
    title: 'Back-end Development',
    description: 'Learn to build robust server-side applications, APIs, and database systems using Node.js, Express, and MongoDB.',
    icon: CpuIcon,
    skills: ['Node.js', 'Express.js', 'REST APIs', 'MongoDB', 'Authentication', 'MVC Architecture'],
    tools: ['VS Code', 'Node.js', 'Postman', 'MongoDB Compass', 'Git'],
    duration: '30 Days',
    plan: {
      week1: ['Intro to Backend & Node.js', 'NPM and Modules', 'Asynchronous JavaScript', 'Building a simple server with Express'],
      week2: ['REST API Principles', 'Routing and Controllers', 'Middleware', 'Intro to NoSQL & MongoDB'],
      week3: ['Mongoose ODM', 'CRUD Operations', 'Authentication with JWT', 'Error Handling'],
      week4: ['Real-World Project: Task Management API', 'Connecting Frontend to Backend', 'Deployment Basics', 'Final Assessment'],
    },
  },
  {
    id: 'ai',
    title: 'Artificial Intelligence',
    description: 'Dive into the world of AI and Machine Learning. Understand core concepts and build intelligent applications.',
    icon: BrainCircuitIcon,
    skills: ['Machine Learning Concepts', 'Python for AI', 'Data Preprocessing', 'Supervised Learning', 'Neural Networks'],
    tools: ['Python', 'Jupyter Notebook', 'Scikit-learn', 'TensorFlow/PyTorch', 'Pandas'],
    duration: '30 Days',
    plan: {
      week1: ['Introduction to AI & ML', 'Python for Data Science (Pandas, NumPy)', 'Data Visualization', 'Data Cleaning and Preprocessing'],
      week2: ['Supervised Learning: Regression & Classification', 'Model Evaluation Metrics', 'Decision Trees and Random Forests', 'Intro to Scikit-learn'],
      week3: ['Unsupervised Learning: Clustering', 'Introduction to Neural Networks', 'Deep Learning with TensorFlow/Keras', 'Image Classification'],
      week4: ['Real-World Project: Predictive Model', 'Model Deployment Concepts', 'Ethics in AI', 'Final Assessment'],
    },
  },
  {
    id: 'data-analyst',
    title: 'Data Analyst',
    description: 'Learn to collect, clean, and analyze data to extract meaningful insights and drive business decisions.',
    icon: BarChartIcon,
    skills: ['Data Analysis', 'SQL', 'Python (Pandas)', 'Data Visualization', 'Statistical Analysis'],
    tools: ['SQL Server', 'Python', 'Jupyter', 'Tableau', 'Excel'],
    duration: '30 Days',
    plan: {
      week1: ['Intro to Data Analysis', 'Excel for Data Analysis', 'SQL Fundamentals', 'Filtering and Sorting Data'],
      week2: ['Advanced SQL (Joins, Aggregations)', 'Data Cleaning with Python (Pandas)', 'Data Wrangling', 'Exploratory Data Analysis (EDA)'],
      week3: ['Data Visualization with Matplotlib/Seaborn', 'Intro to Tableau', 'Building Dashboards', 'Statistical Concepts'],
      week4: ['Real-World Project: Sales Data Analysis', 'Communicating Insights', 'Presentation Skills', 'Final Assessment'],
    },
  },
  {
    id: 'sql',
    title: 'SQL',
    description: 'Master the language of databases. Learn to write complex queries to manipulate and retrieve data efficiently.',
    icon: DatabaseIcon,
    skills: ['Relational Databases', 'SQL Queries', 'Joins', 'Subqueries', 'Window Functions', 'Data Modeling'],
    tools: ['MySQL Workbench', 'PostgreSQL', 'pgAdmin', 'DB Browser for SQLite'],
    duration: '30 Days',
    plan: {
      week1: ['Database Fundamentals', 'Intro to SQL', 'SELECT, FROM, WHERE clauses', 'Filtering, Sorting, and Limiting'],
      week2: ['Aggregate Functions (COUNT, SUM, AVG)', 'GROUP BY and HAVING', 'Table Joins (INNER, LEFT, RIGHT)', 'Data Types and Constraints'],
      week3: ['Subqueries', 'Common Table Expressions (CTEs)', 'Window Functions', 'Data Modification (INSERT, UPDATE, DELETE)'],
      week4: ['Database Design Principles', 'Indexes and Performance Tuning', 'Real-World Project: Querying a Sample Database', 'Final Assessment'],
    },
  },
];


export const QUIZZES: { [key: string]: Quiz } = {
  java: {
    id: 'java-q1',
    title: 'Java Fundamentals Quiz',
    questions: [
      {
        question: 'Which of these is not a Java keyword?',
        options: ['class', 'int', 'string', 'public'],
        answer: 'string',
      },
      {
        question: 'What is the entry point of a Java program?',
        options: ['main() method', 'start() method', 'run() method', 'init() method'],
        answer: 'main() method',
      },
    ],
  },
  python: {
    id: 'python-q1',
    title: 'Python Basics Quiz',
    questions: [
      {
        question: 'Which data type is used to store a sequence of characters?',
        options: ['int', 'float', 'str', 'list'],
        answer: 'str',
      },
      {
        question: 'How do you start a single-line comment in Python?',
        options: ['//', '#', '/*', '--'],
        answer: '#',
      },
    ],
  },
  // Add more quizzes for other courses
};
